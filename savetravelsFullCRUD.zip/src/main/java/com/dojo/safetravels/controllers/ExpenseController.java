package com.dojo.safetravels.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dojo.safetravels.models.Expense;
import com.dojo.safetravels.services.ExpenseService;

@Controller //****renders jsp page
public class ExpenseController {
	
	@Autowired //****auto sets dependency injection
	ExpenseService expenseService;

	@RequestMapping("/")
	public String home() {
		return "redirect:/expenses";
	}
	
	@RequestMapping("/expenses")
	public String index(Model model) {
		//since we're selecting all expenses, we'll need a list specifically ("expenses") of all expenses
		List<Expense> expenses = expenseService.allExpenses();
		model.addAttribute("expenses", expenses);
		return "/index.jsp";
	}
	
	
	@PostMapping("/expenses")
	public String index(
			
			@Valid @ModelAttribute("expense") Expense expense, BindingResult result, Model model) {
			if (result.hasErrors()) {
				List<Expense> expenses = expenseService.allExpenses();
				model.addAttribute("expenses", expenses);
				return "/index.jsp";
			} else {
				expenseService.createExpense(expense);
				return "redirect:/expenses";
			}
	}
	
	//****@ModelAttribute creates a newExpense object automatically binding to the view model(new.jsp)
	@RequestMapping("/expenses/new")
	public String newExpense(@ModelAttribute("expense") Expense expense) {
		return "new.jsp";
	}
	
	@RequestMapping("expenses/edit/{id}")
	public String showedit(@PathVariable("id") Long id, Model model) {	
		Expense expense = expenseService.findExpense(id);	
		model.addAttribute("expense", expense);
		return "edit.jsp";
	}
	
	@PostMapping("expenses/edit/{id}")
	public String update(
			@PathVariable("id") Long id, Model model, 
			@Valid @ModelAttribute("expense") Expense expense, BindingResult result) {
		if(result.hasErrors()) {
			return "redirect:/edit/{id}";
		}else {
			expenseService.updateExpense(expense);
			return "redirect:/expenses";
		}
	}
	
	@RequestMapping("/expenses/{id}")
	public String show(@PathVariable("id") Long id, Model model) {
		
		model.addAttribute("expense", expenseService.findExpense(id));
		System.out.println("this is the platform solution.");
		
		return "show.jsp";
	}
	
	@DeleteMapping("/expenses/{id}")
	public String delete(@PathVariable("id") Long id) {
		
		expenseService.deleteExpense(id);
		
		return "redirect:/expenses";
	}
}
