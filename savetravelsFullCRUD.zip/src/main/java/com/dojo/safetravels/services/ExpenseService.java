package com.dojo.safetravels.services;

import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import com.dojo.safetravels.models.Expense;
import com.dojo.safetravels.repositories.ExpenseRepository;


@Service
public class ExpenseService {
 
	//creating the instance (expenseRepository) that will be used to call all the methods from the repository.
    private final ExpenseRepository expenseRepository;
    
    //adding the expense repository as a dependency
    public ExpenseService(ExpenseRepository expenseRepository) {
        this.expenseRepository = expenseRepository;
    }
    // returns all the expenses
    public List<Expense> allExpenses() {
        return expenseRepository.findAll();
    }
    // creates an expense and saves it
    public Expense createExpense(Expense e) {
        return expenseRepository.save(e);
    }
    // retrieves an expense
    public Expense findExpense(Long id) {
        Optional<Expense> optionalExpense = expenseRepository.findById(id);
        if(optionalExpense.isPresent()) {
            return optionalExpense.get();
        } else {
            return null;
        }
    }
    
    // updateExpense will take in a Expense object and save it to our database
    // our repository will automatically update an existing Expense object if their IDs match
    public Expense updateExpense(Expense expense) {
		return expenseRepository.save(expense);
	}
	
    // to delete an expense, we simply pass in the expense ID and if our repository finds it, the expense will be deleted
	public void deleteExpense(Long id) {
		Optional<Expense> optionalExpense = expenseRepository.findById(id);
		if(optionalExpense.isPresent()) {
			expenseRepository.deleteById(id);
		}
	}
    
}