package com.dojo.safetravels;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SafetravelsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SafetravelsApplication.class, args);
	}

}
